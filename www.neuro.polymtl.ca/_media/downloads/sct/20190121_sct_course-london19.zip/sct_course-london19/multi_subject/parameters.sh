#!/bin/bash
# set environment variables for the study.
# Julien Cohen-Adad 2019-01-19

# Set every other path relative to the location of this script
export PATH_PARENT=$(dirname `pwd`)

# path to input data (do not add "/" at the end). This path should be absolute (i.e. do not use ".")
export PATH_DATA="${PATH_PARENT}/multi_subject/data"

# Path where to save results (do not add "/" at the end).
export PATH_RESULTS="${PATH_PARENT}/multi_subject/results"
export PATH_QC="${PATH_PARENT}/multi_subject/qc"
