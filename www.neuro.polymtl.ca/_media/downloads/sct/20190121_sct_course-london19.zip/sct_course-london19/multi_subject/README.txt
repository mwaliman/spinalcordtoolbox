
Spinal cord analysis pipeline for the SCT course 2019 (London, UK).


GETTING STARTED
===============

- Optional: install GNU parallel
- Run: ./run_process.sh process_data.sh
- Check QC report (under qc/index.html) and results/


DATA
====

The data are from the Spinal Cord MRI Public Database (site: unf).

The file structure follows the BIDS convention:

data
 |- subj-01
 |- subj-02
 |- subj-03
    |- anat
       |- sub-03_T2w.nii.gz
       |- sub-03_acq-MTon_MTS.nii.gz
       |- sub-03_acq-MToff_MTS.nii.gz



SCT VERSION
===========

This pipeline has been tested on v4.0.0-beta.X, which can be downloaded here:
https://github.com/neuropoly/spinalcordtoolbox/releases

