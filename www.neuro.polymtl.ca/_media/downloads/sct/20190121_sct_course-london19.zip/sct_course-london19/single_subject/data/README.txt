sct_example_data
================

Example data for the Spinal Cord Toolbox (sct_019)
